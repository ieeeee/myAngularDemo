﻿var appDemo = angular.module('app', []);

appDemo
    //directive code area
    .directive('hello', function () {
        return {
            restrict: 'E',
            transclude: true,
            scope: {},
            controller: function ($scope, $element) {
            },
            template: 'Hello World!!!'
        }
    })
    .directive('myDdl', function () {
        return {
            restrict: 'E',
            //replace: true,
            transclude: true,       // 不复制原始HTML内容   
            scope: {                // 设置指令对于的scope 
                name: "@",          // name 值传递 （字符串，单向绑定） 
                amount: "=",        // amount 引用传递（双向绑定） 
                save: "&"           // 保存操作 
            },
            //template: '<p><input type="text" ng-model="name">{{name}}</p><p><input type="text" ng-model="amount">{{amount}}</p><p><input type="button" value="保存" ng-click="save()"></p>',
            templateUrl: 'tpls/myDdl.html',
            controller: function ($scope) {
                $scope.name = "Jhon Simth";
                $scope.amount = "1010110";
                $scope.save = function () {
                    $scope.name = "Save Jhon Simth";
                    //console.log('a');
                }

                this.mdyName = function (name) {

                    $scope.name = "其他指令修改了name: " + name;
                    //console.log(name);
                }
            },
            link: function (scope, element, attrs, controller) {

                //scope.name = attrs.howtoload;

                //console.log(element);
                //console.log(attrs);

                //scope.save();
            }
        }
    })
    .directive('myDdlSub', function () {
        return {
            require: '^myDdl',
            restrict: 'E',
            link: function (scope, element, attrs, myDdlCtrl) {
                myDdlCtrl.mdyName('myDdlSub-aaaa');
            },
            template: '指令myDdlSub ',
        }
    })
        //controllers code area
        .controller('MyDirective', function ($scope) {
            console.log();
        });